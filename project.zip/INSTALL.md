# CS 3110 Final Project

If the `plplot` package is not installed, install with `opam install plplot`. It may prompt the user to install additional packages which the user should use `apt-get install` or `brew install` accordingly.

To use the calculator, simply type 'make calc' and press enter. 