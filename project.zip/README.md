# CS 3110 Final Project

We will build a calculator that solves various types of differential equations. The user will be able to enter the problem to be solved in an easy-to-use REPL. Our calculator will use efficient algorithms to provide the result and potentially, plot solutions.
