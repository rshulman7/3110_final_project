(* [hours_worked] per person *)
let hours_worked = 14
