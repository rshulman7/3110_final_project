open Owl
let f x = Maths.sin x /. x in
Plot.plot_fun f 1. 15.;;
