# CS 3110 Final Project

To use the calculator, simply type 'make calc' and press enter. 